package com.example.homestaybooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HomestaybookingApplicationTests {

    @Test
    void contextLoads() {
    }

}
