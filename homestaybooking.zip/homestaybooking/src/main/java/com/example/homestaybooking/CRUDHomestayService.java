package com.example.homestaybooking;

import com.google.firebase.database.*;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class CRUDHomestayService {
    private DatabaseReference databaseReference;
    public String createHomestay(Homestay homestay) {
        return null;
    }

    public Homestay getHomestay() {
        databaseReference = FirebaseDatabase.getInstance("https://homestaybooking-f8308-default-rtdb.europe-west1.firebasedatabase.app").getReference("homestays");;
        ArrayList<Homestay> homestays = new ArrayList<>();
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot homestaySnapshot : dataSnapshot.getChildren()) {
                    Homestay homestay = homestaySnapshot.getValue(Homestay.class);
                    homestays.add(homestay);
                    // Do something with the book object
                    System.out.println("homestay = " + homestay.getHomestayName());
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.out.println("databaseError = " + databaseError);
            }
        });
        return null;
    }
}
