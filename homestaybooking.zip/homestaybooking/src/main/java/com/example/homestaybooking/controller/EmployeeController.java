package com.example.homestaybooking.controller;

import com.example.homestaybooking.CRUDHomestayService;
import com.example.homestaybooking.Homestay;
import org.springframework.web.bind.annotation.*;

@RestController
public class EmployeeController {


    public CRUDHomestayService crudService;

    public EmployeeController(CRUDHomestayService crudService) {
        this.crudService = crudService;
    }

    @RequestMapping(value = "/employees",method = RequestMethod.GET)
    @ResponseBody
    public String getEmployees() {
        return "employees";
    }

    @PostMapping("/create")
    public String create(@RequestBody Homestay homestay) {
        return crudService.createHomestay(homestay);
    }

    @GetMapping("/get-all-homestay")
    public Homestay get() {
        System.out.println("homestayID = " );
        return crudService.getHomestay();
    }


}
